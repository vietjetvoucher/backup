# Đơn hàng nhanh (v2)

Ứng dụng Python (tkinter), chỉ dùng thư viện chuẩn, không cần cài thêm gói nào.

## Chạy

    python orders_app.py

Trên Windows dùng `pythonw orders_app.py` để không hiện cửa sổ console.

## Tính năng chính

- **Nhập đơn**: dán tin nhắn, tự tách phần nằm giữa hai ký hiệu. Chuột phải ô dán để Copy, Dán, Xóa.
- **Copy**: dòng 1 là mã (nội dung tách), dòng 2 là số lượng.
- **Hoàn thành** (hoặc Ctrl+Enter): lưu vào lịch sử của đối tác đang chọn, rồi xóa ô dán và số lượng.
- **Lịch sử**: thời gian, đối tác, mã, số lượng, thành tiền.
  - Tìm kiếm thông minh: nhiều từ khóa cùng lúc, không phân biệt hoa thường và dấu tiếng Việt.
  - Lọc thời gian nhanh: Hôm nay, Hôm qua, 7 ngày, 30 ngày, Tháng này, Tháng trước, Năm nay, hoặc nhập tùy chọn.
  - Thống kê số đơn, tổng số lượng, doanh thu, trung bình mỗi đơn và tổng theo từng đối tác.
  - Chuột phải: xem chi tiết, copy mã và số lượng, sửa số lượng, xóa. Có xuất CSV (mở được bằng Excel).
- **Đối tác**: thêm, đổi tên, đổi thứ tự, xóa. Mỗi đối tác có giá riêng:
  - Nhân theo số lượng, hoặc theo vùng (ví dụ 1 đến 10 giá 50.000, từ 11 trở lên giá 45.000).
  - Có xem trước thành tiền ở 1, 10 và 50 đơn vị.
- **Cài đặt**:
  - Ký hiệu tách nội dung (mở đầu và kết thúc, mặc định `--`).
  - Giao diện sáng hoặc tối.
  - Cảnh báo khi trùng mã trong cùng một đối tác.
  - Sao lưu dữ liệu.
- **Thông báo**: có biểu tượng ứng dụng, tự tắt sau vài giây. Hộp thoại cũng có biểu tượng.
- **Một cửa sổ duy nhất**: bấm Ẩn hoặc nút X để ẩn. Mở lại ứng dụng sẽ đưa cửa sổ đang chạy lên.

## Dữ liệu

Lưu trong `orders_data.json` cùng thư mục với `orders_app.py`. Nên sao lưu định kỳ bằng nút "Sao lưu dữ liệu" ở tab Cài đặt.

## Tùy chỉnh trong code

- `WIDTH_RATIO`, `HEIGHT_RATIO`: kích thước cửa sổ theo tỷ lệ màn hình.
- `INSTANCE_PORT`: cổng đảm bảo một cửa sổ (đổi nếu bị trùng).
- `THEMES`: bảng màu sáng và tối.
