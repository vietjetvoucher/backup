"""
Đơn hàng nhanh - ứng dụng nhập đơn từ tin nhắn khách hàng.
Chỉ dùng thư viện chuẩn của Python (tkinter). Không cần cài thêm gói nào.
"""
import csv
import copy
import json
import os
import queue
import re
import shutil
import socket
import threading
import unicodedata
import uuid
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import ttk, filedialog

# ====================== CẤU HÌNH ======================
APP_TITLE = "Đơn hàng nhanh"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "orders_data.json")
INSTANCE_PORT = 48765          # cổng đảm bảo chỉ một cửa sổ ứng dụng
DT_FMT = "%Y-%m-%d %H:%M:%S"   # định dạng lưu trong file
UI_FMT = "%d/%m/%Y %H:%M"      # định dạng hiển thị
DATE_FMT = "%d/%m/%Y"
DT_PLACEHOLDER = "dd/mm/yyyy hh:mm"
DT_HINT = "Ví dụ: 09/11/2026 08:00, hoặc chỉ ngày 09/11/2026"
WIDTH_RATIO = 1 / 3            # rộng = 1/3 màn hình
HEIGHT_RATIO = 1 / 2           # cao = 1/2 màn hình
ALL = "Tất cả"

DEFAULT_SETTINGS = {"start": "--", "end": "--", "theme": "light", "warn_dup": True}
DEFAULT_CODE_NAME = "Mã thường"

THEMES = {
    "light": dict(BG="#eef2f7", CARD="#ffffff", INPUT="#ffffff", ZEBRA="#f6f8fb",
                  ACCENT="#2563eb", ACCENT_D="#1d4ed8", TEXT="#1e293b", MUTED="#64748b",
                  OK="#16a34a", DANGER="#dc2626", GHOST="#e2e8f0", GHOST_D="#cbd5e1"),
    "dark": dict(BG="#0f172a", CARD="#1e293b", INPUT="#0f172a", ZEBRA="#213047",
                 ACCENT="#3b82f6", ACCENT_D="#2563eb", TEXT="#e2e8f0", MUTED="#94a3b8",
                 OK="#22c55e", DANGER="#ef4444", GHOST="#334155", GHOST_D="#475569"),
}
C = dict(THEMES["light"])      # bảng màu đang dùng, cập nhật khi đổi giao diện

FONT = ("Segoe UI", 9)
FONT_B = ("Segoe UI", 9, "bold")
FONT_BIG = ("Segoe UI", 13, "bold")
FONT_MONEY = ("Segoe UI", 11, "bold")

PRESETS = ["Tất cả", "Hôm nay", "Hôm qua", "7 ngày qua", "30 ngày qua",
           "Tháng này", "Tháng trước", "Năm nay", "Tùy chọn"]

ICON = None        # biểu tượng lớn, gán trong main()
ICON_SM = None     # biểu tượng nhỏ cho thông báo
MASK = "***"


# ====================== TIỆN ÍCH ======================
def money(v):
    return f"{int(round(v)):,}".replace(",", ".") + " đ"


def fmt_qty(n):
    return f"{int(n):,}".replace(",", ".") if n else ""


def parse_int(s):
    digits = re.sub(r"\D", "", s or "")
    return int(digits) if digits else 0


def norm(s):
    """Chuyển về chữ thường, bỏ dấu tiếng Việt để tìm kiếm thông minh."""
    s = (s or "").replace("đ", "d").replace("Đ", "D")
    s = unicodedata.normalize("NFD", s)
    s = "".join(ch for ch in s if unicodedata.category(ch) != "Mn")
    return s.lower()


def parse_dt(s, end=False):
    s = (s or "").strip()
    if not s:
        return None
    for fmt in (UI_FMT, DATE_FMT):
        try:
            d = datetime.strptime(s, fmt)
            if fmt == DATE_FMT and end:
                d = d.replace(hour=23, minute=59, second=59)
            return d
        except ValueError:
            pass
    raise ValueError(s)


def preset_range(name):
    now = datetime.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if name == "Hôm nay":
        return today, None
    if name == "Hôm qua":
        y = today - timedelta(days=1)
        return y, y
    if name == "7 ngày qua":
        return today - timedelta(days=6), None
    if name == "30 ngày qua":
        return today - timedelta(days=29), None
    if name == "Tháng này":
        return today.replace(day=1), None
    if name == "Tháng trước":
        last = today.replace(day=1) - timedelta(days=1)
        return last.replace(day=1), last
    if name == "Năm nay":
        return today.replace(month=1, day=1), None
    return None, None


def empty_pricing():
    return {"mode": "unit", "unit_price": 0, "tiers": []}


def calc_amount(pricing, qty):
    if qty <= 0:
        return 0
    if pricing.get("mode") == "tier":
        for t in pricing.get("tiers", []):
            hi = t["to"]
            if qty >= t["from"] and (hi is None or qty <= hi):
                return qty * t["price"]
        return 0
    return qty * pricing.get("unit_price", 0)


def build_marker_re(settings):
    st = settings.get("start") or "--"
    en = settings.get("end") or "--"
    return re.compile(re.escape(st) + r"(.*?)" + re.escape(en), re.S)


def load_data():
    try:
        with open(DATA_FILE, encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = {}
    data.setdefault("partners", [])
    data.setdefault("codes", [])
    st = dict(DEFAULT_SETTINGS)
    st.update(data.get("settings", {}))
    data["settings"] = st

    # Bảo đảm luôn có ít nhất một loại mã
    if not data["codes"]:
        data["codes"].append({"id": uuid.uuid4().hex, "name": DEFAULT_CODE_NAME})
    default = data["codes"][0]

    # Chuyển giá cũ (một giá cho mỗi đối tác) sang giá theo loại mã
    for p in data["partners"]:
        p.setdefault("history", [])
        if "prices" not in p:
            p["prices"] = {}
            if "pricing" in p:
                p["prices"][default["id"]] = p.pop("pricing")
        p.pop("pricing", None)

    # Lịch sử cũ được gắn vào loại mã mặc định
    for p in data["partners"]:
        for h in p["history"]:
            h.setdefault("code_id", default["id"])
            h.setdefault("code_name", default["name"])
    return data


def save_data(data):
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DATA_FILE)


def partner_price(p, cid):
    return (p.get("prices") or {}).get(cid) or empty_pricing()


def make_icon(size):
    """Vẽ biểu tượng: nền xanh, tờ đơn trắng, dấu tích xanh lá."""
    s = size
    img = tk.PhotoImage(width=s, height=s)
    img.put(C["ACCENT"], to=(0, 0, s, s))
    x1, x2 = int(s * 0.25), int(s * 0.70)
    y1, y2 = int(s * 0.18), int(s * 0.82)
    img.put("#ffffff", to=(x1, y1, x2, y2))
    for ratio in (0.36, 0.50, 0.64):
        y = int(s * ratio)
        img.put("#93c5fd", to=(x1 + int(s * 0.08), y, x2 - int(s * 0.08), y + max(2, s // 20)))
    cx, cy, r = int(s * 0.74), int(s * 0.74), max(3, int(s * 0.18))
    for yy in range(cy - r, cy + r + 1):
        for xx in range(cx - r, cx + r + 1):
            if (xx - cx) ** 2 + (yy - cy) ** 2 <= r * r:
                img.put("#22c55e", to=(xx, yy))
    return img


def ensure_single_instance():
    """Trả về socket server nếu là instance đầu tiên, None nếu đã có instance khác."""
    try:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.bind(("127.0.0.1", INSTANCE_PORT))
        srv.listen(5)
        return srv
    except OSError:
        try:
            with socket.create_connection(("127.0.0.1", INSTANCE_PORT), timeout=1) as c:
                c.sendall(b"SHOW")
        except OSError:
            pass
        return None


# ====================== Ô NHẬP CÓ CHỮ GỢI Ý ======================
class PlaceholderEntry(tk.Entry):
    """Ô nhập hiện chữ gợi ý màu xám khi trống; mất hiệu lực khi người dùng gõ."""

    def __init__(self, parent, placeholder, on_edit=None, width=12):
        super().__init__(parent, width=width, relief="flat", bd=0, highlightthickness=1)
        self.ph = placeholder
        self.on_edit = on_edit
        self.showing_ph = True
        self.insert(0, placeholder)
        self.bind("<FocusIn>", self._focus_in)
        self.bind("<FocusOut>", self._focus_out)
        self.bind("<KeyRelease>", self._key)
        self.refresh_colors()

    def refresh_colors(self):
        self.configure(bg=C["INPUT"], fg=C["MUTED"] if self.showing_ph else C["TEXT"],
                       insertbackground=C["TEXT"], highlightbackground=C["GHOST_D"],
                       highlightcolor=C["ACCENT"], selectbackground=C["ACCENT"],
                       selectforeground="white")

    def _focus_in(self, _=None):
        if self.showing_ph:
            self.delete(0, "end")
            self.showing_ph = False
            self.refresh_colors()

    def _focus_out(self, _=None):
        if not self.showing_ph and not self.get().strip():
            self.set_value("")
        self.refresh_colors()

    def _key(self, _=None):
        if self.on_edit and not self.showing_ph:
            self.on_edit()

    def value(self):
        return "" if self.showing_ph else self.get().strip()

    def set_value(self, s):
        self.delete(0, "end")
        if s:
            self.showing_ph = False
            self.insert(0, s)
        else:
            self.showing_ph = True
            self.insert(0, self.ph)
        self.refresh_colors()


# ====================== HỘP THOẠI & THÔNG BÁO ======================
class Dialog(tk.Toplevel):
    """Hộp thoại có biểu tượng ứng dụng. Trả về nút đã bấm và nội dung ô nhập (nếu có)."""

    def __init__(self, parent, title, message, buttons=("OK",), initial=None):
        super().__init__(parent)
        self.withdraw()
        self.title(title)
        self.configure(bg=C["CARD"])
        self.transient(parent)
        self.resizable(False, False)
        self.iconphoto(False, ICON)
        self.choice = len(buttons) - 1
        self.text = None

        body = tk.Frame(self, bg=C["CARD"], padx=22, pady=18)
        body.pack(fill="both", expand=True)
        tk.Label(body, text=message, bg=C["CARD"], fg=C["TEXT"], font=FONT,
                 justify="left", wraplength=380, anchor="w").pack(anchor="w", fill="x")

        self.entry = None
        if initial is not None:
            self.entry = ttk.Entry(body, width=44)
            self.entry.insert(0, initial)
            self.entry.pack(fill="x", pady=(12, 0))
            self.entry.select_range(0, "end")

        row = tk.Frame(body, bg=C["CARD"])
        row.pack(fill="x", pady=(16, 0))
        for i, label in enumerate(buttons):
            ttk.Button(row, text=label,
                       style="Accent.TButton" if i == 0 else "Ghost.TButton",
                       command=lambda i=i: self._done(i)).pack(side="right", padx=(8, 0))

        self.bind("<Return>", lambda e: self._done(0))
        self.bind("<Escape>", lambda e: self._done(len(buttons) - 1))
        self.protocol("WM_DELETE_WINDOW", lambda: self._done(len(buttons) - 1))

        self.update_idletasks()
        px = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_reqwidth()) // 2
        py = parent.winfo_rooty() + (parent.winfo_height() - self.winfo_reqheight()) // 2
        self.geometry(f"+{max(px, 0)}+{max(py, 0)}")
        self.deiconify()
        try:
            self.grab_set()
        except tk.TclError:
            pass
        if self.entry is not None:
            self.entry.focus_set()
        self.wait_window()

    def _done(self, i):
        self.choice = i
        if self.entry is not None:
            self.text = self.entry.get()
        self.destroy()


def ask(parent, title, message, buttons=("OK",), initial=None):
    d = Dialog(parent, title, message, buttons, initial)
    return d.choice, d.text


def confirm(parent, message, title=APP_TITLE):
    return ask(parent, title, message, ("Có", "Không"))[0] == 0


def alert(parent, message, title=APP_TITLE):
    ask(parent, title, message, ("Đóng",))


def ask_text(parent, title, prompt, initial=""):
    choice, text = ask(parent, title, prompt, ("Lưu", "Hủy"), initial=initial)
    if choice == 0 and text is not None:
        return text.strip()
    return None


class Toast(tk.Toplevel):
    """Thông báo nhỏ phía dưới cửa sổ, có biểu tượng ứng dụng, tự tắt sau vài giây."""

    def __init__(self, parent, text, kind="ok"):
        super().__init__(parent)
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        color = {"ok": C["OK"], "err": C["DANGER"]}.get(kind, C["ACCENT"])
        frame = tk.Frame(self, bg=C["CARD"], highlightthickness=2, highlightbackground=color)
        frame.pack()
        tk.Label(frame, image=ICON_SM, text="  " + text, compound="left",
                 bg=C["CARD"], fg=C["TEXT"], font=FONT_B, padx=14, pady=10).pack()
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() - self.winfo_reqwidth()) // 2
        y = parent.winfo_rooty() + parent.winfo_height() - self.winfo_reqheight() - 28
        self.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        self.after(2200, self.destroy)


def _paint(w, kind):
    if kind == "input":
        w.configure(bg=C["INPUT"], fg=C["TEXT"], insertbackground=C["TEXT"],
                    selectbackground=C["ACCENT"], selectforeground="white",
                    highlightthickness=1, highlightbackground=C["GHOST_D"],
                    highlightcolor=C["ACCENT"], bd=0)
    elif kind == "ph":
        w.refresh_colors()
    elif kind == "out":
        w.configure(bg=C["ZEBRA"], fg=C["TEXT"], highlightthickness=1,
                    highlightbackground=C["GHOST_D"], bd=0)
    elif kind == "list":
        w.configure(bg=C["INPUT"], fg=C["TEXT"], selectbackground=C["ACCENT"],
                    selectforeground="white", highlightthickness=1,
                    highlightbackground=C["GHOST_D"], bd=0, activestyle="none")
    elif kind == "menu":
        w.configure(bg=C["CARD"], fg=C["TEXT"], activebackground=C["ACCENT"],
                    activeforeground="white", bd=0)
    elif kind == "canvas":
        w.configure(bg=C["BG"])


# ====================== ỨNG DỤNG ======================
class App:
    def __init__(self, root, server):
        self.root = root
        self.server = server
        self.data = load_data()
        self.s = self.data["settings"]
        C.update(THEMES.get(self.s.get("theme"), THEMES["light"]))
        self.marker_re = build_marker_re(self.s)

        self.cmd_q = queue.Queue()
        self.themed = []
        self.hist_rows = {}
        self.view_rows = []
        self.extracted = ""
        self.sel_pid = None
        self.tiers_list = []
        self.show_money = False
        self._range_lock = False
        self._fmt_lock = False
        self._toast = None

        root.title(APP_TITLE)
        root.iconphoto(True, ICON)
        root.protocol("WM_DELETE_WINDOW", root.withdraw)
        root.minsize(420, 320)
        root.bind("<Control-Return>", lambda e: self.complete())
        root.bind_all("<MouseWheel>", self._on_wheel)
        root.bind_all("<Button-4>", self._on_wheel)
        root.bind_all("<Button-5>", self._on_wheel)

        self._style()
        self._build()
        self.apply_theme()
        self._place()
        self.refresh_codes()
        self.refresh_partners()
        self.refresh_history()
        self.update_example()
        threading.Thread(target=self._listen, daemon=True).start()
        self._poll()

    # ---------- style & giao diện ----------
    def _style(self):
        s = ttk.Style(self.root)
        s.theme_use("clam")
        s.configure(".", background=C["CARD"], foreground=C["TEXT"], font=FONT,
                    bordercolor=C["GHOST_D"], lightcolor=C["CARD"], darkcolor=C["CARD"],
                    troughcolor=C["GHOST"], focuscolor=C["ACCENT"])
        s.configure("TFrame", background=C["CARD"])
        s.configure("TLabel", background=C["CARD"], foreground=C["TEXT"], font=FONT)
        s.configure("Head.TFrame", background=C["BG"])
        s.configure("Head.TLabel", background=C["BG"], foreground=C["TEXT"], font=FONT_BIG)
        s.configure("Title.TLabel", background=C["CARD"], foreground=C["TEXT"], font=FONT_B)
        s.configure("Muted.TLabel", background=C["CARD"], foreground=C["MUTED"])
        s.configure("Money.TLabel", background=C["CARD"], foreground=C["ACCENT"], font=FONT_MONEY)
        s.configure("Stat.TLabel", background=C["CARD"], foreground=C["TEXT"], font=FONT_B)
        s.configure("TNotebook", background=C["BG"], borderwidth=0)
        s.configure("TNotebook.Tab", padding=(12, 5), font=FONT_B,
                    background=C["GHOST"], foreground=C["TEXT"])
        s.map("TNotebook.Tab", background=[("selected", C["CARD"]), ("!selected", C["GHOST"])],
              foreground=[("selected", C["ACCENT"])])
        s.configure("TEntry", fieldbackground=C["INPUT"], foreground=C["TEXT"],
                    insertcolor=C["TEXT"], padding=4)
        s.configure("TCombobox", fieldbackground=C["INPUT"], foreground=C["TEXT"],
                    background=C["GHOST"], arrowcolor=C["TEXT"], padding=3)
        s.map("TCombobox", fieldbackground=[("readonly", C["INPUT"])],
              foreground=[("readonly", C["TEXT"])],
              selectbackground=[("readonly", C["INPUT"])],
              selectforeground=[("readonly", C["TEXT"])])
        s.configure("TRadiobutton", background=C["CARD"], foreground=C["TEXT"], font=FONT)
        s.configure("TCheckbutton", background=C["CARD"], foreground=C["TEXT"], font=FONT)

        for name, bg, fg, act in [("Accent", C["ACCENT"], "white", C["ACCENT_D"]),
                                  ("Ghost", C["GHOST"], C["TEXT"], C["GHOST_D"]),
                                  ("Danger", C["DANGER"], "white", "#b91c1c")]:
            s.configure(f"{name}.TButton", background=bg, foreground=fg, font=FONT_B,
                        padding=(10, 6), borderwidth=0, relief="flat")
            s.map(f"{name}.TButton", background=[("active", act)])

        s.configure("Treeview", background=C["INPUT"], fieldbackground=C["INPUT"],
                    foreground=C["TEXT"], rowheight=24, font=FONT, borderwidth=0)
        s.configure("Treeview.Heading", font=FONT_B, background=C["GHOST"],
                    foreground=C["TEXT"], relief="flat")
        s.map("Treeview", background=[("selected", C["ACCENT"])],
              foreground=[("selected", "white")])
        s.map("Treeview.Heading", background=[("active", C["GHOST_D"])])
        s.configure("TScrollbar", background=C["GHOST"], troughcolor=C["CARD"],
                    bordercolor=C["CARD"], arrowcolor=C["TEXT"])

    def apply_theme(self):
        self._style()
        self.root.configure(bg=C["BG"])
        for w, kind in self.themed:
            _paint(w, kind)
        self.tree.tag_configure("odd", background=C["ZEBRA"])
        self.root.option_add("*TCombobox*Listbox.background", C["INPUT"])
        self.root.option_add("*TCombobox*Listbox.foreground", C["TEXT"])
        self.root.option_add("*TCombobox*Listbox.selectBackground", C["ACCENT"])
        self.root.option_add("*TCombobox*Listbox.selectForeground", "white")

    def _place(self):
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        w = max(480, int(sw * WIDTH_RATIO))
        h = max(420, int(sh * HEIGHT_RATIO))
        self.root.geometry(f"{w}x{h}+{sw - w}+0")

    def _on_wheel(self, e):
        if isinstance(e.widget, (tk.Text, tk.Listbox, ttk.Treeview)):
            return
        if getattr(e, "num", None) == 4:
            step = -1
        elif getattr(e, "num", None) == 5:
            step = 1
        else:
            step = -1 if e.delta > 0 else 1
        self.canvas.yview_scroll(step, "units")

    # ---------- xây dựng giao diện ----------
    def _build(self):
        outer = tk.Frame(self.root, bg=C["BG"])
        outer.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(outer, highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(outer, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas, bg=C["BG"])
        self.win_id = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(
            scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(
            self.win_id, width=e.width))
        self.themed += [(self.canvas, "canvas"), (self.inner, "canvas")]

        head = ttk.Frame(self.inner, style="Head.TFrame", padding=(12, 8, 10, 6))
        head.pack(fill="x")
        ttk.Label(head, text=APP_TITLE, style="Head.TLabel").pack(side="left")
        ttk.Button(head, text="Thoát", style="Danger.TButton",
                   command=self.quit_app).pack(side="right")
        self.money_btn_var = tk.StringVar(value="Hiện tiền")
        ttk.Button(head, textvariable=self.money_btn_var, style="Ghost.TButton",
                   command=self.toggle_money).pack(side="right", padx=6)

        self.nb = ttk.Notebook(self.inner)
        self.nb.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tab_order = ttk.Frame(self.nb, padding=12)
        self.tab_hist = ttk.Frame(self.nb, padding=12)
        self.tab_part = ttk.Frame(self.nb, padding=12)
        self.tab_set = ttk.Frame(self.nb, padding=12)
        self.nb.add(self.tab_order, text="Nhập đơn")
        self.nb.add(self.tab_hist, text="Lịch sử")
        self.nb.add(self.tab_part, text="Đối tác")
        self.nb.add(self.tab_set, text="Cài đặt")

        self._build_order()
        self._build_history()
        self._build_partners()
        self._build_settings()
        self._build_menus()

    def _build_menus(self):
        self.txt_menu = tk.Menu(self.root, tearoff=0, font=FONT)
        self.txt_menu.add_command(label="Copy", command=self.txt_copy)
        self.txt_menu.add_command(label="Dán",
                                  command=lambda: self.txt.event_generate("<<Paste>>"))
        self.txt_menu.add_command(label="Xóa", command=self.txt_clear)
        self.txt_menu.add_separator()
        self.txt_menu.add_command(label="Chọn tất cả",
                                  command=lambda: self.txt.tag_add("sel", "1.0", "end-1c"))

        self.tree_menu = tk.Menu(self.root, tearoff=0, font=FONT)
        self.tree_menu.add_command(label="Xem chi tiết", command=self.show_detail)
        self.tree_menu.add_command(label="Copy mã và số lượng", command=self.copy_selected)
        self.tree_menu.add_command(label="Sửa số lượng", command=self.edit_qty)
        self.tree_menu.add_separator()
        self.tree_menu.add_command(label="Xóa", command=self.delete_selected)
        self.themed += [(self.txt_menu, "menu"), (self.tree_menu, "menu")]

    def _build_order(self):
        f = self.tab_order
        row = ttk.Frame(f)
        row.pack(fill="x")
        ttk.Label(row, text="Đối tác").pack(side="left")
        self.partner_var = tk.StringVar()
        self.partner_cb = ttk.Combobox(row, textvariable=self.partner_var,
                                       state="readonly", width=24)
        self.partner_cb.pack(side="left", padx=8, fill="x", expand=True)
        self.partner_cb.bind("<<ComboboxSelected>>", lambda e: self.update_amount())

        ttk.Label(f, text="Dán tin nhắn khách hàng", style="Title.TLabel").pack(
            anchor="w", pady=(14, 4))
        self.txt = tk.Text(f, height=7, wrap="word", font=FONT, padx=8, pady=6)
        self.txt.pack(fill="x")
        self.txt.bind("<<Modified>>", self.extract)
        self.txt.bind("<Button-3>", self.show_txt_menu)
        self.txt.bind("<Button-2>", self.show_txt_menu)
        self.themed.append((self.txt, "input"))
        self.hint_lbl = ttk.Label(f, style="Muted.TLabel", wraplength=560)
        self.hint_lbl.pack(anchor="w", pady=(3, 0))

        ttk.Label(f, text="Mã (nội dung tách)", style="Title.TLabel").pack(
            anchor="w", pady=(12, 4))
        self.out = tk.Text(f, height=3, wrap="word", font=FONT, padx=8, pady=6,
                           state="disabled")
        self.out.pack(fill="x")
        self.themed.append((self.out, "out"))

        self.status = ttk.Label(f, text="", style="Muted.TLabel", wraplength=560)
        self.status.pack(anchor="w", pady=(6, 0))

        qrow = ttk.Frame(f)
        qrow.pack(fill="x", pady=(10, 0))
        self.amount_lbl = ttk.Label(qrow, text="Thành tiền: 0 đ", style="Money.TLabel",
                                    cursor="hand2")
        self.amount_lbl.pack(side="right")
        self.amount_lbl.bind("<Button-1>", lambda e: self.toggle_money())

        ttk.Label(qrow, text="Loại mã").pack(side="left")
        self.code_var = tk.StringVar()
        self.code_cb = ttk.Combobox(qrow, textvariable=self.code_var, state="readonly", width=14)
        self.code_cb.pack(side="left", padx=(6, 12))
        self.code_cb.bind("<<ComboboxSelected>>", lambda e: self.update_amount())

        ttk.Label(qrow, text="Số lượng").pack(side="left")
        self.qty_var = tk.StringVar()
        self.qty_var.trace_add("write", self._on_qty_change)
        self.qty_entry = ttk.Entry(qrow, textvariable=self.qty_var, width=9, justify="center")
        self.qty_entry.pack(side="left", padx=(6, 0))
        self.qty_entry.bind("<Up>", lambda e: self.bump_qty(1))
        self.qty_entry.bind("<Down>", lambda e: self.bump_qty(-1))
        self.qty_entry.bind("<Return>", lambda e: self.complete())

        btns = ttk.Frame(f)
        btns.pack(fill="x", pady=(14, 4))
        self.copy_btn = ttk.Button(btns, text="Copy", style="Ghost.TButton", command=self.copy)
        self.copy_btn.pack(side="left", expand=True, fill="x", padx=(0, 6))
        ttk.Button(btns, text="Hoàn thành", style="Accent.TButton",
                   command=self.complete).pack(side="left", expand=True, fill="x", padx=(6, 0))

    def _build_history(self):
        f = self.tab_hist
        r1 = ttk.Frame(f)
        r1.pack(fill="x")
        ttk.Label(r1, text="Tìm").pack(side="left")
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *a: self.refresh_history())
        ttk.Entry(r1, textvariable=self.search_var).pack(side="left", padx=(6, 10),
                                                        fill="x", expand=True)
        ttk.Label(r1, text="Đối tác").pack(side="left")
        self.filter_var = tk.StringVar(value=ALL)
        self.filter_cb = ttk.Combobox(r1, textvariable=self.filter_var,
                                      state="readonly", width=12)
        self.filter_cb.pack(side="left", padx=(6, 10))
        self.filter_cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_history())
        ttk.Label(r1, text="Loại").pack(side="left")
        self.filter_code_var = tk.StringVar(value=ALL)
        self.filter_code_cb = ttk.Combobox(r1, textvariable=self.filter_code_var,
                                           state="readonly", width=12)
        self.filter_code_cb.pack(side="left", padx=(6, 0))
        self.filter_code_cb.bind("<<ComboboxSelected>>", lambda e: self.refresh_history())

        r2 = ttk.Frame(f)
        r2.pack(fill="x", pady=(8, 0))
        ttk.Label(r2, text="Thời gian").pack(side="left")
        self.preset_var = tk.StringVar(value=PRESETS[0])
        pcb = ttk.Combobox(r2, textvariable=self.preset_var, values=PRESETS,
                           state="readonly", width=13)
        pcb.pack(side="left", padx=(6, 10))
        pcb.bind("<<ComboboxSelected>>", self.on_preset)
        ttk.Label(r2, text="Từ").pack(side="left")
        self.from_e = PlaceholderEntry(r2, DT_PLACEHOLDER, on_edit=self._on_range_edit, width=16)
        self.from_e.pack(side="left", padx=(4, 8), ipady=3)
        ttk.Label(r2, text="đến").pack(side="left")
        self.to_e = PlaceholderEntry(r2, DT_PLACEHOLDER, on_edit=self._on_range_edit, width=16)
        self.to_e.pack(side="left", padx=4, ipady=3)
        self.themed.append((self.from_e, "ph"))
        self.themed.append((self.to_e, "ph"))
        ttk.Label(f, text=DT_HINT, style="Muted.TLabel").pack(anchor="w", pady=(3, 0))

        r3 = ttk.Frame(f)
        r3.pack(fill="x", pady=(8, 0))
        self.stat1 = ttk.Label(r3, style="Stat.TLabel")
        self.stat1.pack(side="left")
        ttk.Button(r3, text="Xuất CSV", style="Ghost.TButton",
                   command=self.export_csv).pack(side="right")
        ttk.Button(r3, text="Xóa bộ lọc", style="Ghost.TButton",
                   command=self.reset_filters).pack(side="right", padx=6)

        self.stat2 = ttk.Label(f, style="Money.TLabel")
        self.stat2.pack(anchor="w", pady=(4, 0))
        self.stat3 = ttk.Label(f, style="Muted.TLabel", wraplength=560)
        self.stat3.pack(anchor="w")
        self.stat4 = ttk.Label(f, style="Muted.TLabel", wraplength=560)
        self.stat4.pack(anchor="w")

        wrap = ttk.Frame(f)
        wrap.pack(fill="both", expand=True, pady=(8, 0))
        cols = ("time", "partner", "ctype", "code", "qty", "amount")
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings",
                                 height=8, selectmode="extended")
        spec = [("time", "Thời gian", 115, "w", False),
                ("partner", "Đối tác", 90, "w", False),
                ("ctype", "Loại", 80, "w", False),
                ("code", "Mã", 200, "w", True),
                ("qty", "SL", 56, "center", False),
                ("amount", "Thành tiền", 100, "e", False)]
        for c, t, w, a, stretch in spec:
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, anchor=a, stretch=stretch)
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", self.show_detail)
        self.tree.bind("<Delete>", lambda e: self.delete_selected())
        self.tree.bind("<Control-c>", lambda e: self.copy_selected())
        self.tree.bind("<Button-3>", self.show_tree_menu)
        self.tree.bind("<Button-2>", self.show_tree_menu)

        ttk.Label(f, text="Nhấp đúp để xem chi tiết  ·  Chuột phải để thao tác  ·  Delete để xóa",
                  style="Muted.TLabel").pack(anchor="w", pady=(4, 0))

    def _build_partners(self):
        f = self.tab_part
        left = ttk.Frame(f)
        left.pack(side="left", fill="y")
        ttk.Label(left, text="Danh sách đối tác", style="Title.TLabel").pack(anchor="w")
        self.plist = tk.Listbox(left, width=28, height=12, font=FONT, exportselection=False)
        self.plist.pack(fill="both", expand=True, pady=(6, 8))
        self.plist.bind("<<ListboxSelect>>", self.on_plist_select)
        self.themed.append((self.plist, "list"))

        grid = ttk.Frame(left)
        grid.pack(fill="x")
        actions = [("Thêm", self.add_partner, "Accent"),
                   ("Đổi tên", self.rename_partner, "Ghost"),
                   ("Lên", lambda: self.move_partner(-1), "Ghost"),
                   ("Xuống", lambda: self.move_partner(1), "Ghost"),
                   ("Xóa", self.delete_partner, "Danger")]
        for i, (label, cmd, style) in enumerate(actions):
            ttk.Button(grid, text=label, style=f"{style}.TButton", command=cmd).grid(
                row=i // 2, column=i % 2, sticky="ew", padx=2, pady=2)
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

        right = ttk.Frame(f)
        right.pack(side="left", fill="both", expand=True, padx=(16, 0))
        self.pricing_title = ttk.Label(right, text="Chọn đối tác để sửa giá", style="Title.TLabel")
        self.pricing_title.pack(anchor="w")

        crow = ttk.Frame(right)
        crow.pack(fill="x", pady=(8, 0))
        ttk.Label(crow, text="Giá cho loại mã").pack(side="left")
        self.price_code_var = tk.StringVar()
        self.price_code_cb = ttk.Combobox(crow, textvariable=self.price_code_var,
                                          state="readonly", width=16)
        self.price_code_cb.pack(side="left", padx=8)
        self.price_code_cb.bind("<<ComboboxSelected>>", lambda e: self._load_price_editor())

        self.mode_var = tk.StringVar(value="unit")
        ttk.Radiobutton(right, text="Nhân theo số lượng", variable=self.mode_var,
                        value="unit", command=self.update_preview).pack(anchor="w", pady=(8, 0))
        ttk.Radiobutton(right, text="Theo vùng số lượng", variable=self.mode_var,
                        value="tier", command=self.update_preview).pack(anchor="w")

        r = ttk.Frame(right)
        r.pack(fill="x", pady=(8, 0))
        ttk.Label(r, text="Đơn giá").pack(side="left")
        self.unit_var = tk.StringVar()
        self.unit_var.trace_add("write", self.update_preview)
        ttk.Entry(r, textvariable=self.unit_var, width=14).pack(side="left", padx=8)

        ttk.Label(right, text="Các vùng (chỉ dùng khi chọn theo vùng)",
                  style="Muted.TLabel").pack(anchor="w", pady=(10, 2))
        self.tree_t = ttk.Treeview(right, columns=("from", "to", "price"),
                                   show="headings", height=5, selectmode="browse")
        for c, t, w in [("from", "Từ SL", 80), ("to", "Đến SL", 80), ("price", "Đơn giá", 120)]:
            self.tree_t.heading(c, text=t)
            self.tree_t.column(c, width=w, anchor="center")
        self.tree_t.pack(fill="x")

        addrow = ttk.Frame(right)
        addrow.pack(fill="x", pady=(6, 0))
        self.t_from = tk.StringVar()
        self.t_to = tk.StringVar()
        self.t_price = tk.StringVar()
        ttk.Label(addrow, text="Từ").pack(side="left")
        ttk.Entry(addrow, textvariable=self.t_from, width=6).pack(side="left", padx=(4, 8))
        ttk.Label(addrow, text="đến").pack(side="left")
        ttk.Entry(addrow, textvariable=self.t_to, width=6).pack(side="left", padx=(4, 8))
        ttk.Label(addrow, text="giá").pack(side="left")
        ttk.Entry(addrow, textvariable=self.t_price, width=10).pack(side="left", padx=(4, 8))
        ttk.Button(addrow, text="Thêm vùng", style="Accent.TButton",
                   command=self.add_tier).pack(side="left", padx=2)
        ttk.Button(addrow, text="Xóa vùng", style="Danger.TButton",
                   command=self.remove_tier).pack(side="left", padx=2)
        ttk.Label(right, text="Để trống 'Đến SL' nghĩa là trở lên",
                  style="Muted.TLabel").pack(anchor="w", pady=(4, 0))

        self.preview_lbl = ttk.Label(right, style="Muted.TLabel", wraplength=340)
        self.preview_lbl.pack(anchor="w", pady=(10, 0))
        ttk.Button(right, text="Lưu giá", style="Accent.TButton",
                   command=self.save_pricing).pack(fill="x", pady=(10, 0))

    def _build_settings(self):
        f = self.tab_set

        ttk.Label(f, text="Loại mã", style="Title.TLabel").pack(anchor="w")
        ttk.Label(f, text="Mỗi loại mã có giá riêng cho từng đối tác (sửa ở tab Đối tác). "
                          "Nhân bản sẽ sao chép cả giá.",
                  style="Muted.TLabel", wraplength=560).pack(anchor="w", pady=(2, 6))
        crow = ttk.Frame(f)
        crow.pack(fill="x")
        self.codes_lb = tk.Listbox(crow, width=30, height=6, font=FONT, exportselection=False)
        self.codes_lb.pack(side="left", fill="y")
        self.themed.append((self.codes_lb, "list"))
        grid = ttk.Frame(crow)
        grid.pack(side="left", padx=(10, 0), fill="x")
        actions = [("Thêm", self.add_code, "Accent"),
                   ("Đổi tên", self.rename_code, "Ghost"),
                   ("Nhân bản", self.dup_code, "Accent"),
                   ("Xóa", self.delete_code, "Danger"),
                   ("Lên", lambda: self.move_code(-1), "Ghost"),
                   ("Xuống", lambda: self.move_code(1), "Ghost")]
        for i, (label, cmd, style) in enumerate(actions):
            ttk.Button(grid, text=label, style=f"{style}.TButton", width=10, command=cmd).grid(
                row=i // 2, column=i % 2, sticky="ew", padx=2, pady=2)

        ttk.Label(f, text="Ký hiệu tách nội dung", style="Title.TLabel").pack(anchor="w", pady=(18, 0))
        g = ttk.Frame(f)
        g.pack(fill="x", pady=(6, 0))
        self.s_start = tk.StringVar(value=self.s["start"])
        self.s_end = tk.StringVar(value=self.s["end"])
        ttk.Label(g, text="Mở đầu").grid(row=0, column=0, sticky="w")
        ttk.Entry(g, textvariable=self.s_start, width=10).grid(row=0, column=1, padx=8)
        ttk.Label(g, text="Kết thúc").grid(row=0, column=2, sticky="w", padx=(12, 0))
        ttk.Entry(g, textvariable=self.s_end, width=10).grid(row=0, column=3, padx=8)
        ttk.Button(g, text="Lưu ký hiệu", style="Accent.TButton",
                   command=self.save_markers).grid(row=0, column=4, padx=(12, 0))
        self.example_lbl = ttk.Label(f, style="Muted.TLabel", wraplength=560)
        self.example_lbl.pack(anchor="w", pady=(4, 0))

        ttk.Label(f, text="Giao diện", style="Title.TLabel").pack(anchor="w", pady=(18, 4))
        self.theme_var = tk.StringVar(value=self.s.get("theme", "light"))
        ttk.Radiobutton(f, text="Sáng", value="light", variable=self.theme_var,
                        command=self.on_theme_change).pack(anchor="w")
        ttk.Radiobutton(f, text="Tối", value="dark", variable=self.theme_var,
                        command=self.on_theme_change).pack(anchor="w")

        ttk.Label(f, text="Tùy chọn", style="Title.TLabel").pack(anchor="w", pady=(18, 4))
        self.warn_var = tk.BooleanVar(value=bool(self.s.get("warn_dup", True)))
        ttk.Checkbutton(f, text="Cảnh báo khi trùng mã trong cùng một đối tác",
                        variable=self.warn_var, command=self.on_warn_toggle).pack(anchor="w")

        ttk.Label(f, text="Dữ liệu", style="Title.TLabel").pack(anchor="w", pady=(18, 4))
        ttk.Button(f, text="Sao lưu dữ liệu", style="Ghost.TButton",
                   command=self.backup).pack(anchor="w")
        ttk.Label(f, text=f"File dữ liệu: {DATA_FILE}", style="Muted.TLabel",
                  wraplength=560).pack(anchor="w", pady=(6, 0))

    # ---------- loại mã ----------
    def codes(self):
        return self.data["codes"]

    def code_by_name(self, name):
        return next((c for c in self.codes() if c["name"] == name), None)

    def code_by_id(self, cid):
        return next((c for c in self.codes() if c["id"] == cid), None)

    def code_name_of(self, h, names_by_id):
        return names_by_id.get(h.get("code_id")) or h.get("code_name", "—")

    def refresh_codes(self, select_id=None):
        names = [c["name"] for c in self.codes()]
        for cb, var in [(self.code_cb, self.code_var), (self.price_code_cb, self.price_code_var)]:
            cb["values"] = names
            if var.get() not in names:
                var.set(names[0] if names else "")
        self.filter_code_cb["values"] = [ALL] + names
        if self.filter_code_var.get() not in [ALL] + names:
            self.filter_code_var.set(ALL)

        self.codes_lb.delete(0, "end")
        for c in self.codes():
            priced = sum(1 for p in self.data["partners"] if c["id"] in (p.get("prices") or {}))
            self.codes_lb.insert("end", f"{c['name']}   ·   giá {priced}/{len(self.data['partners'])} đối tác")
        if select_id:
            idx = next((i for i, c in enumerate(self.codes()) if c["id"] == select_id), None)
            if idx is not None:
                self.codes_lb.selection_clear(0, "end")
                self.codes_lb.selection_set(idx)
                self.codes_lb.see(idx)
        self.update_amount()
        self._load_price_editor()

    def selected_code(self):
        idx = self.codes_lb.curselection()
        return self.codes()[idx[0]] if idx else None

    def add_code(self):
        name = ask_text(self.root, "Loại mã mới", "Tên loại mã:")
        if not name:
            return
        if name in [c["name"] for c in self.codes()]:
            return alert(self.root, "Tên loại mã đã tồn tại.")
        c = {"id": uuid.uuid4().hex, "name": name}
        self.codes().append(c)
        save_data(self.data)
        self.refresh_codes(select_id=c["id"])
        self.notify(f"Đã thêm loại mã {name}.")

    def rename_code(self):
        c = self.selected_code()
        if not c:
            return self.notify("Hãy chọn loại mã trước.", "err")
        name = ask_text(self.root, "Đổi tên loại mã", "Tên mới:", initial=c["name"])
        if not name or name == c["name"]:
            return
        if name in [x["name"] for x in self.codes()]:
            return alert(self.root, "Tên loại mã đã tồn tại.")
        c["name"] = name
        save_data(self.data)
        self.refresh_codes(select_id=c["id"])
        self.refresh_history()
        self.notify("Đã đổi tên loại mã.")

    def dup_code(self):
        c = self.selected_code()
        if not c:
            return self.notify("Hãy chọn loại mã cần nhân bản.", "err")
        name = ask_text(self.root, "Nhân bản loại mã",
                        "Tên loại mã mới (giá sẽ được sao chép):",
                        initial=f"{c['name']} (bản sao)")
        if not name:
            return
        if name in [x["name"] for x in self.codes()]:
            return alert(self.root, "Tên loại mã đã tồn tại.")
        new = {"id": uuid.uuid4().hex, "name": name}
        self.codes().append(new)
        for p in self.data["partners"]:
            prices = p.setdefault("prices", {})
            if c["id"] in prices:
                prices[new["id"]] = copy.deepcopy(prices[c["id"]])
        save_data(self.data)
        self.refresh_codes(select_id=new["id"])
        self.refresh_partners(select_pid=self.sel_pid)
        self.notify(f"Đã nhân bản thành {name}.")

    def delete_code(self):
        c = self.selected_code()
        if not c:
            return self.notify("Hãy chọn loại mã trước.", "err")
        if len(self.codes()) <= 1:
            return alert(self.root, "Cần có ít nhất một loại mã.")
        used = sum(1 for p in self.data["partners"] for h in p["history"] if h.get("code_id") == c["id"])
        extra = f"\nLịch sử {used} đơn vẫn được giữ với tên loại mã cũ." if used else ""
        if not confirm(self.root, f"Xóa loại mã '{c['name']}'?{extra}"):
            return
        self.codes().remove(c)
        for p in self.data["partners"]:
            (p.get("prices") or {}).pop(c["id"], None)
        save_data(self.data)
        self.refresh_codes()
        self.refresh_partners(select_pid=self.sel_pid)
        self.refresh_history()
        self.notify(f"Đã xóa loại mã {c['name']}.")

    def move_code(self, d):
        idx = self.codes_lb.curselection()
        if not idx:
            return
        i = idx[0]
        j = i + d
        cs = self.codes()
        if not (0 <= j < len(cs)):
            return
        cs[i], cs[j] = cs[j], cs[i]
        save_data(self.data)
        self.refresh_codes(select_id=cs[j]["id"])

    # ---------- ẩn/hiện tiền ----------
    def m(self, v):
        return money(v) if self.show_money else MASK

    def toggle_money(self):
        self.show_money = not self.show_money
        self.money_btn_var.set("Ẩn tiền" if self.show_money else "Hiện tiền")
        self.update_amount()
        self.update_preview()
        self.refresh_history()

    # ---------- cài đặt ----------
    def update_example(self):
        st, en = self.s["start"], self.s["end"]
        self.example_lbl.config(text=f"Ví dụ: {st}Nội dung khách{en} → chỉ lấy phần giữa hai ký hiệu")
        self.hint_lbl.config(text=f"Lấy nội dung nằm giữa {st} và {en}. "
                                  f"Nếu không có, sẽ lấy toàn bộ tin nhắn.  ·  Ctrl+Enter để hoàn thành")

    def save_markers(self):
        st = self.s_start.get().strip()
        en = self.s_end.get().strip()
        if not st or not en:
            return self.notify("Ký hiệu không được để trống.", "err")
        self.s["start"], self.s["end"] = st, en
        self.marker_re = build_marker_re(self.s)
        save_data(self.data)
        self.update_example()
        self._extract_from_text()
        self.notify("Đã lưu ký hiệu tách.")

    def on_theme_change(self):
        self.s["theme"] = self.theme_var.get()
        C.update(THEMES[self.s["theme"]])
        save_data(self.data)
        self.apply_theme()

    def on_warn_toggle(self):
        self.s["warn_dup"] = bool(self.warn_var.get())
        save_data(self.data)

    def backup(self):
        path = filedialog.asksaveasfilename(
            parent=self.root, defaultextension=".json",
            initialfile=f"orders_backup_{datetime.now():%Y%m%d_%H%M}.json",
            filetypes=[("JSON", "*.json")])
        if not path:
            return
        save_data(self.data)
        shutil.copyfile(DATA_FILE, path)
        self.notify("Đã sao lưu dữ liệu.")

    # ---------- thông báo & tiện ích ----------
    def notify(self, text, kind="ok"):
        if self._toast is not None:
            try:
                self._toast.destroy()
            except tk.TclError:
                pass
        self._toast = Toast(self.root, text, kind)

    def set_status(self, text, key="MUTED"):
        self.status.config(text=text, foreground=C[key])

    def partner_names(self):
        return [p["name"] for p in self.data["partners"]]

    def get_partner(self, name):
        return next((p for p in self.data["partners"] if p["name"] == name), None)

    def get_partner_by_id(self, pid):
        return next((p for p in self.data["partners"] if p["id"] == pid), None)

    def current_partner(self):
        return self.get_partner(self.partner_var.get())

    def current_code(self):
        return self.code_by_name(self.code_var.get())

    def selected_partner(self):
        idx = self.plist.curselection()
        return self.data["partners"][idx[0]] if idx else None

    def get_qty(self):
        return parse_int(self.qty_var.get())

    def _on_qty_change(self, *a):
        if not self._fmt_lock:
            raw = self.qty_var.get()
            new = fmt_qty(parse_int(raw))
            if new != raw:
                self._fmt_lock = True
                self.qty_var.set(new)
                self._fmt_lock = False
        self.update_amount()

    def bump_qty(self, d):
        self.qty_var.set(fmt_qty(max(0, self.get_qty() + d)))

    def update_amount(self):
        p = self.current_partner()
        c = self.current_code()
        amt = calc_amount(partner_price(p, c["id"]), self.get_qty()) if (p and c) else 0
        self.amount_lbl.config(text=f"Thành tiền: {self.m(amt)}")

    # ---------- đối tác ----------
    def refresh_partners(self, select_pid=None):
        names = self.partner_names()
        self.partner_cb["values"] = names
        if self.partner_var.get() not in names:
            self.partner_var.set(names[0] if names else "")
        self.filter_cb["values"] = [ALL] + names
        if self.filter_var.get() not in [ALL] + names:
            self.filter_var.set(ALL)

        self.plist.delete(0, "end")
        for p in self.data["partners"]:
            self.plist.insert("end", f"{p['name']}   ·   {len(p['history'])} đơn")
        if select_pid:
            idx = next((i for i, p in enumerate(self.data["partners"]) if p["id"] == select_pid), None)
            if idx is not None:
                self.plist.selection_clear(0, "end")
                self.plist.selection_set(idx)
                self.plist.see(idx)
        self.update_amount()

    def on_plist_select(self, _=None):
        p = self.selected_partner()
        if not p:
            return
        self.sel_pid = p["id"]
        self._load_price_editor()

    def _load_price_editor(self):
        if not hasattr(self, "tiers_list"):
            return
        p = self.get_partner_by_id(self.sel_pid)
        c = self.code_by_name(self.price_code_var.get())
        if not p or not c:
            self.pricing_title.config(text="Chọn đối tác để sửa giá")
            self.tiers_list = []
            self._fill_tiers()
            self.update_preview()
            return
        pr = partner_price(p, c["id"])
        self.pricing_title.config(text=f"Giá của {p['name']}  ·  {c['name']}")
        self.tiers_list = [dict(t) for t in pr.get("tiers", [])]
        self.mode_var.set(pr.get("mode", "unit"))
        up = pr.get("unit_price", 0)
        self.unit_var.set(str(up) if up else "")
        self._fill_tiers()
        self.update_preview()

    def add_partner(self):
        name = ask_text(self.root, "Đối tác mới", "Tên đối tác:")
        if not name:
            return
        if name in self.partner_names():
            return alert(self.root, "Tên đối tác đã tồn tại.")
        p = {"id": uuid.uuid4().hex, "name": name, "prices": {}, "history": []}
        self.data["partners"].append(p)
        save_data(self.data)
        self.refresh_partners(select_pid=p["id"])
        self.sel_pid = p["id"]
        self.refresh_codes()
        self.notify(f"Đã thêm đối tác {name}.")

    def rename_partner(self):
        p = self.selected_partner()
        if not p:
            return self.notify("Hãy chọn đối tác trước.", "err")
        name = ask_text(self.root, "Đổi tên", "Tên mới:", initial=p["name"])
        if not name or name == p["name"]:
            return
        if name in self.partner_names():
            return alert(self.root, "Tên đối tác đã tồn tại.")
        p["name"] = name
        save_data(self.data)
        self.refresh_partners(select_pid=p["id"])
        self._load_price_editor()
        self.refresh_history()
        self.notify("Đã đổi tên đối tác.")

    def move_partner(self, d):
        idx = self.plist.curselection()
        if not idx:
            return
        i = idx[0]
        j = i + d
        parts = self.data["partners"]
        if not (0 <= j < len(parts)):
            return
        parts[i], parts[j] = parts[j], parts[i]
        save_data(self.data)
        self.refresh_partners(select_pid=parts[j]["id"])

    def delete_partner(self):
        p = self.selected_partner()
        if not p:
            return self.notify("Hãy chọn đối tác trước.", "err")
        n = len(p["history"])
        extra = f" và toàn bộ {n} đơn trong lịch sử" if n else ""
        if not confirm(self.root, f"Xóa đối tác '{p['name']}'{extra}?"):
            return
        self.data["partners"].remove(p)
        save_data(self.data)
        self.sel_pid = None
        self.refresh_partners()
        self.refresh_codes()
        self.refresh_history()
        self.notify(f"Đã xóa đối tác {p['name']}.")

    def _fill_tiers(self):
        self.tree_t.delete(*self.tree_t.get_children())
        for i, t in enumerate(self.tiers_list):
            self.tree_t.insert("", "end", iid=str(i), values=(
                t["from"], t["to"] if t["to"] is not None else "trở lên", money(t["price"])))

    def _editor_pricing(self):
        return {"mode": self.mode_var.get(),
                "unit_price": parse_int(self.unit_var.get()),
                "tiers": [dict(t) for t in self.tiers_list]}

    def update_preview(self, *a):
        if not hasattr(self, "preview_lbl"):
            return
        pr = self._editor_pricing()
        parts = [f"SL {q}: {self.m(calc_amount(pr, q))}" for q in (1, 10, 50)]
        self.preview_lbl.config(text="Xem trước   " + "   ·   ".join(parts))

    def add_tier(self):
        try:
            lo = int(self.t_from.get())
            hi_s = self.t_to.get().strip()
            hi = int(hi_s) if hi_s else None
            price = parse_int(self.t_price.get())
            if lo < 1 or (hi is not None and hi < lo) or price <= 0:
                raise ValueError
        except ValueError:
            return alert(self.root, "Vùng không hợp lệ.\nVí dụ: từ 1, đến 10, giá 50000")
        self.tiers_list.append({"from": lo, "to": hi, "price": price})
        self.tiers_list.sort(key=lambda t: t["from"])
        self._fill_tiers()
        self.t_from.set("")
        self.t_to.set("")
        self.t_price.set("")
        self.update_preview()

    def remove_tier(self):
        sel = self.tree_t.selection()
        if not sel:
            return
        for iid in sorted((int(i) for i in sel), reverse=True):
            del self.tiers_list[iid]
        self._fill_tiers()
        self.update_preview()

    def save_pricing(self):
        p = self.get_partner_by_id(self.sel_pid)
        c = self.code_by_name(self.price_code_var.get())
        if not p or not c:
            return self.notify("Hãy chọn đối tác và loại mã trước.", "err")
        p.setdefault("prices", {})[c["id"]] = self._editor_pricing()
        save_data(self.data)
        self.update_amount()
        self.refresh_partners(select_pid=p["id"])
        self.notify(f"Đã lưu giá {c['name']} cho {p['name']}.")

    # ---------- nhập đơn ----------
    def show_txt_menu(self, e):
        try:
            self.txt_menu.tk_popup(e.x_root, e.y_root)
        finally:
            self.txt_menu.grab_release()

    def txt_copy(self):
        try:
            sel = self.txt.get("sel.first", "sel.last")
        except tk.TclError:
            sel = self.txt.get("1.0", "end-1c")
        self.root.clipboard_clear()
        self.root.clipboard_append(sel)

    def txt_clear(self):
        self.txt.delete("1.0", "end")
        self.txt.edit_modified(False)
        self._extract_from_text()

    def extract(self, _=None):
        if not self.txt.edit_modified():
            return
        self.txt.edit_modified(False)
        self._extract_from_text()

    def _extract_from_text(self):
        raw = self.txt.get("1.0", "end-1c")
        st, en = self.s["start"], self.s["end"]
        m = self.marker_re.search(raw)
        content = m.group(1).strip() if m else ""

        self.out.config(state="normal")
        self.out.delete("1.0", "end")
        if not raw.strip():
            self.extracted = ""
            self.set_status("")
        elif content:
            self.extracted = content
            self.set_status("Đã tách nội dung.", "OK")
        else:
            self.extracted = raw.strip()
            if m:
                msg = f"Nội dung giữa {st} và {en} đang trống. Đã lấy toàn bộ tin nhắn làm mã."
            else:
                msg = f"Không thấy ký hiệu {st} ... {en}. Đã lấy toàn bộ tin nhắn làm mã."
            self.set_status(msg, "DANGER")
        self.out.insert("1.0", self.extracted)
        self.out.config(state="disabled")

    def _payload(self):
        qty = self.get_qty()
        return f"{self.extracted}\n{qty if qty > 0 else ''}"

    def copy(self):
        if not self.extracted:
            return self.set_status("Chưa có nội dung để copy.", "DANGER")
        self.root.clipboard_clear()
        self.root.clipboard_append(self._payload())
        self.copy_btn.config(text="Đã copy")
        self.root.after(1500, lambda: self.copy_btn.config(text="Copy"))
        self.set_status("Đã copy: dòng 1 là mã, dòng 2 là số lượng.", "OK")

    def complete(self):
        p = self.current_partner()
        c = self.current_code()
        qty = self.get_qty()
        if not p:
            return self.set_status("Chưa có đối tác. Thêm ở tab Đối tác.", "DANGER")
        if not c:
            return self.set_status("Chưa có loại mã. Thêm ở tab Cài đặt.", "DANGER")
        if not self.extracted:
            return self.set_status("Chưa có nội dung để lưu.", "DANGER")
        if qty <= 0:
            return self.set_status("Hãy nhập số lượng.", "DANGER")

        if self.s.get("warn_dup", True):
            dup = any(h.get("content", "").strip() == self.extracted for h in p["history"])
            if dup and not confirm(self.root, f"Mã này đã có trong lịch sử của {p['name']}.\nVẫn lưu thêm?"):
                return

        amount = calc_amount(partner_price(p, c["id"]), qty)
        p["history"].append({
            "id": uuid.uuid4().hex,
            "time": datetime.now().strftime(DT_FMT),
            "content": self.extracted,
            "code_id": c["id"],
            "code_name": c["name"],
            "quantity": qty,
            "amount": amount,
        })
        save_data(self.data)

        self.txt.delete("1.0", "end")
        self.txt.edit_modified(False)
        self.qty_var.set("")
        self._extract_from_text()
        self.refresh_partners(select_pid=p["id"])
        self.refresh_history()
        self.notify(f"Đã lưu · {p['name']} · {c['name']} · {self.m(amount)}")
        self.txt.focus_set()

    # ---------- lịch sử ----------
    def on_preset(self, _=None):
        name = self.preset_var.get()
        if name == "Tùy chọn":
            return
        d1, d2 = preset_range(name)
        self._range_lock = True
        self.from_e.set_value(d1.strftime(DATE_FMT) if d1 else "")
        self.to_e.set_value(d2.strftime(DATE_FMT) if d2 else "")
        self._range_lock = False
        self.preset_var.set(name)
        self.refresh_history()

    def _on_range_edit(self):
        if self._range_lock:
            return
        self.preset_var.set("Tùy chọn")
        self.refresh_history()

    def reset_filters(self):
        self._range_lock = True
        self.from_e.set_value("")
        self.to_e.set_value("")
        self._range_lock = False
        self.search_var.set("")
        self.filter_var.set(ALL)
        self.filter_code_var.set(ALL)
        self.preset_var.set(PRESETS[0])
        self.refresh_history()

    def refresh_history(self):
        if not hasattr(self, "tree"):
            return
        try:
            d1 = parse_dt(self.from_e.value())
            d2 = parse_dt(self.to_e.value(), end=True)
        except ValueError:
            self.stat1.config(text="Sai định dạng ngày. Dùng dd/mm/yyyy hoặc dd/mm/yyyy hh:mm")
            return

        names_by_id = {c["id"]: c["name"] for c in self.codes()}
        flt = self.filter_var.get()
        flt_code = self.filter_code_var.get()
        tokens = norm(self.search_var.get()).split()
        rows = []
        for p in self.data["partners"]:
            if flt not in ("", ALL) and p["name"] != flt:
                continue
            for h in p["history"]:
                cname = self.code_name_of(h, names_by_id)
                if flt_code not in ("", ALL) and cname != flt_code:
                    continue
                t = datetime.strptime(h["time"], DT_FMT)
                if d1 and t < d1:
                    continue
                if d2 and t > d2:
                    continue
                hay = norm(" ".join([t.strftime(UI_FMT), p["name"], cname, h.get("content", ""),
                                     str(h["quantity"]), str(int(h["amount"])),
                                     money(h["amount"])]))
                if tokens and not all(tok in hay for tok in tokens):
                    continue
                rows.append((t, p, cname, h))
        rows.sort(key=lambda r: r[0], reverse=True)
        self.view_rows = rows

        self.tree.delete(*self.tree.get_children())
        self.hist_rows.clear()
        for i, (t, p, cname, h) in enumerate(rows):
            iid = str(i)
            self.hist_rows[iid] = (p["name"], h)
            code = h.get("content", "").replace("\n", " ")
            self.tree.insert("", "end", iid=iid, tags=("odd",) if i % 2 else (), values=(
                t.strftime(UI_FMT), p["name"], cname, code,
                fmt_qty(h["quantity"]), self.m(h["amount"])))

        total_qty = sum(h["quantity"] for *_, h in rows)
        revenue = sum(h["amount"] for *_, h in rows)
        avg = revenue / len(rows) if rows else 0
        self.stat1.config(text=f"Số đơn: {len(rows)}   ·   Tổng SL: {fmt_qty(total_qty) or 0}"
                               f"   ·   TB/đơn: {self.m(avg)}")
        self.stat2.config(text=f"Doanh thu: {self.m(revenue)}")

        if flt in ("", ALL):
            summary = {}
            for _, p, _, h in rows:
                c = summary.setdefault(p["name"], [0, 0])
                c[0] += 1
                c[1] += h["amount"]
            self.stat3.config(text="Theo đối tác:  " + "   ·   ".join(
                f"{n}: {c} đơn, {self.m(r)}" for n, (c, r) in summary.items()))
        else:
            self.stat3.config(text="")

        if flt_code in ("", ALL):
            summary = {}
            for _, _, cname, h in rows:
                c = summary.setdefault(cname, [0, 0])
                c[0] += 1
                c[1] += h["amount"]
            self.stat4.config(text="Theo loại mã:  " + "   ·   ".join(
                f"{n}: {c} đơn, {self.m(r)}" for n, (c, r) in summary.items()))
        else:
            self.stat4.config(text="")

    def show_tree_menu(self, e):
        iid = self.tree.identify_row(e.y)
        if iid:
            if iid not in self.tree.selection():
                self.tree.selection_set(iid)
            try:
                self.tree_menu.tk_popup(e.x_root, e.y_root)
            finally:
                self.tree_menu.grab_release()

    def _first_selected(self):
        sel = self.tree.selection()
        return sel[0] if sel else None

    def show_detail(self, _=None):
        iid = self._first_selected()
        if not iid:
            return
        pname, h = self.hist_rows[iid]
        names_by_id = {c["id"]: c["name"] for c in self.codes()}
        alert(self.root,
              f"Đối tác: {pname}\nLoại mã: {self.code_name_of(h, names_by_id)}\n"
              f"Thời gian: {datetime.strptime(h['time'], DT_FMT).strftime(UI_FMT)}\n"
              f"Số lượng: {fmt_qty(h['quantity'])}\nThành tiền: {self.m(h['amount'])}\n\n"
              f"Mã:\n{h.get('content', '')}",
              title="Chi tiết đơn")

    def copy_selected(self):
        iid = self._first_selected()
        if not iid:
            return
        _, h = self.hist_rows[iid]
        self.root.clipboard_clear()
        self.root.clipboard_append(f"{h.get('content', '')}\n{h['quantity']}")
        self.notify("Đã copy mã và số lượng.")

    def edit_qty(self):
        sel = self.tree.selection()
        if len(sel) != 1:
            return self.notify("Chọn đúng 1 dòng để sửa.", "err")
        pname, h = self.hist_rows[sel[0]]
        p = self.get_partner(pname)
        preview = h.get("content", "").replace("\n", " ")[:60]
        val = ask_text(self.root, "Sửa số lượng", f"Số lượng mới cho mã:\n{preview}",
                       initial=fmt_qty(h["quantity"]))
        if val is None:
            return
        qty = parse_int(val)
        if qty <= 0:
            return self.notify("Số lượng không hợp lệ.", "err")
        old_qty = h["quantity"]
        c = self.code_by_id(h.get("code_id"))
        if p and c:
            h["amount"] = calc_amount(partner_price(p, c["id"]), qty)
        elif old_qty:
            # Loại mã đã bị xóa: giữ đơn giá cũ
            h["amount"] = h["amount"] / old_qty * qty
        h["quantity"] = qty
        save_data(self.data)
        self.refresh_partners(select_pid=self.sel_pid)
        self.refresh_history()
        self.notify("Đã cập nhật số lượng (theo giá hiện tại của đối tác).")

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        if not confirm(self.root, f"Xóa {len(sel)} mục đã chọn?"):
            return
        for iid in sel:
            pname, h = self.hist_rows[iid]
            p = self.get_partner(pname)
            if p:
                p["history"] = [x for x in p["history"] if x is not h]
        save_data(self.data)
        self.refresh_partners(select_pid=self.sel_pid)
        self.refresh_history()
        self.notify(f"Đã xóa {len(sel)} mục.")

    def export_csv(self):
        if not self.view_rows:
            return self.notify("Không có dữ liệu để xuất.", "err")
        path = filedialog.asksaveasfilename(
            parent=self.root, defaultextension=".csv",
            initialfile=f"lich_su_{datetime.now():%Y%m%d_%H%M}.csv",
            filetypes=[("CSV", "*.csv")])
        if not path:
            return
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["Thời gian", "Đối tác", "Loại mã", "Mã", "Số lượng", "Thành tiền"])
            for t, p, cname, h in self.view_rows:
                w.writerow([t.strftime(UI_FMT), p["name"], cname,
                            h.get("content", "").replace("\n", " "),
                            h["quantity"], int(h["amount"])])
        self.notify(f"Đã xuất {len(self.view_rows)} dòng ra CSV.")

    # ---------- một cửa sổ duy nhất ----------
    def _listen(self):
        while True:
            try:
                conn, _ = self.server.accept()
            except OSError:
                return
            try:
                with conn:
                    if conn.recv(16).startswith(b"SHOW"):
                        self.cmd_q.put("show")
            except OSError:
                pass

    def _poll(self):
        try:
            while True:
                self.cmd_q.get_nowait()
                self.show_window()
        except queue.Empty:
            pass
        self.root.after(200, self._poll)

    def show_window(self):
        self.root.deiconify()
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after(150, lambda: self.root.attributes("-topmost", False))
        self.root.focus_force()

    def quit_app(self):
        try:
            self.server.close()
        except OSError:
            pass
        self.root.destroy()


# ====================== MAIN ======================
def main():
    global ICON, ICON_SM
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("DonHangNhanh.App.4")
        except Exception:
            pass

    server = ensure_single_instance()
    if server is None:      # đã có instance đang chạy -> đã đánh thức nó, thoát
        return

    root = tk.Tk()
    ICON = make_icon(64)
    ICON_SM = make_icon(20)
    App(root, server)
    root.mainloop()


if __name__ == "__main__":
    main()
